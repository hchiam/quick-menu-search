1) download zip file
2) unzip folder
3) chrome://extensions/
4) Developer mode
5) Load unpacked
6) select the unzipped folder
7) go to a web page
8) click on the extension icon
9) Ctrl+Shift+F (or hit Esc to close)
10) Tab or Shift+Tab to quickly focus the next link